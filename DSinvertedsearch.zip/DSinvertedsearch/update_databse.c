#include "inverted_search.h"

void update_database( Wlist *head[], Flist **f_head)
{
    char file_name[FNAME_SIZE];
    //prompt the user to enter file_name

    printf("Enter the file name to update the database:\n");
    scanf("%s" , file_name);

    // validate the file -------> implement 

	int empty;
	empty = isFileEmpty(file_name);
	if(empty == FILE_NOTAVAILABLE)
	{
	    printf("File ; %s is not available\n",file_name);
	    printf("Hence we are not adding into file linked list\n");
	   
	}
	else if(empty == FILE_EMPTY)
	{
	    printf("File ; %s is not available\n",file_name);
	    printf("Hence we are not adding into file linked list\n");
	   
	}
	else
	{
	    int ret_value=to_create_list_of_files(f_head , file_name);
	    if(ret_value == SUCCESS)
	    {
		printf("Successful : Inserting the file name : %s into file linked list\n" , file_name);
		
	    }
	    else if (ret_value == REPEATATION)
	    {
		printf("This file name : %s is repeated. Do not add more than once\n",file_name);
	    }
	    else
	    {
		printf("FAILURE\n");
	    }
	}	


    // add to file linked list

    while(*f_head)
    {
	if(!strcmp((*f_head)->file_name , file_name))
	{
	    create_database(*f_head ,head);
	}
	*f_head = (*f_head)->link;
	}
	printf("Created database");
}
    

