#include "inverted_search.h"

int main(int argc , char *argv[])
{
    system("clear");
	Wlist *head[27] = { NULL };
	char option;
	int choice;
	char word[WORD_SIZE];
	int value;
    //validate CLA

    if(argc <= 1 )
    {
	printf("Enter the valid no. arguments\n");
	printf("./SList.exe file1.txt file2.txt...\n");
	return 0;
    }
    //create list of filenames
    // declare head pointer

    Flist *f_head = NULL;

    //Validate the file 
    	file_validation_n_file_list(&f_head , argv);

	if(f_head == NULL)
	{
	    printf("NO files are available in the file linked list\n");
	    printf("Hence the process terminated\n");
	    return 1;
	}

	//Prompt the menu to user for choice
	do
	{	
		printf("Select your choice among following options \n1. Create DATABASE \n2. Display Database \n3. Update DATABASE \n4. Search \n5. Save Database \nEnter your choice ");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1:
				printf("creating datbase");
				//create_database
				create_database(f_head , head);
				break;
				
			case 2:
				// display database
				display_database(head);
				break;
			case 3:
				//update database
				update_database(head , &f_head);
				break;

			case 4:
				//search
				printf("Enter the word to search in database:\n");
				scanf("%s" , word);
				value = tolower(word[0])%97;
			   	if(!(value >=0 && value <= 25))
					value = 26;
				search(head[value],word);
				break;

			case 5:
				save_database(head);
				break;

			default:
				printf("\nEnter proper choice");
				break;

		}
		printf("\nDo you want to continue? \n Enter y/Y to continue and n/N to discontinue ");
		scanf(" %c",&option);
		if(option == 'n' || option == 'N')
			break;
	}while(option == 'y' || 'Y');	
return 0;



}

