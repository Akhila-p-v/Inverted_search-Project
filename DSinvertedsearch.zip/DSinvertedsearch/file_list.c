#include "inverted_search.h"

void file_validation_n_file_list(Flist **f_head, char *argv[])
{

    int i = 1 , empty ;
    while(argv[i] != NULL)
    {
	empty = isFileEmpty(argv[i]);
	if(empty == FILE_NOTAVAILABLE)
	{
	    printf("File ; %s is not available\n",argv[i]);
	    printf("Hence we are not adding into file linked list\n");
	    i++;
	    continue;
	}
	else if(empty == FILE_EMPTY)
	{
	    printf("File ; %s is not available\n",argv[i]);
	    printf("Hence we are not adding into file linked list\n");
	    i++;
	    continue;
	}
	else
	{
	    int ret_value=to_create_list_of_files(f_head , argv[i]);
	    if(ret_value == SUCCESS)
	    {
		printf("Successful : Inserting the file name : %s into file linked list\n" , argv[i]);
		i++;
	    }
	    else if (ret_value == REPEATATION)
	    {
		printf("This file name : %s is repeated. Do not add more than once\n", argv[i]);
		i++;
	    }
	    else
	    {
		printf("FAILURE\n");
	    }
	}
    }
}
int isFileEmpty(char *filename)
{

     FILE *fptr = fopen(filename , "r" );
     if(fptr == NULL)
     {
	 	if(errno == ENOENT)
		 {
		     return FILE_NOTAVAILABLE;
	 	}
     }
     fseek(fptr , 0 , SEEK_END);
     if(ftell(fptr) == 0 )
	 return FILE_EMPTY;
}
int to_create_list_of_files(Flist **f_head, char *name)
{
    //create a linked list 
		Flist *new = malloc(sizeof(Flist));
		if( new == NULL )
		{
			return FAILURE;
		}
		strcpy(new->file_name,name);
		new->link = NULL;
		if(*f_head == NULL)
		{
			*f_head = new;
			return SUCCESS;
		}
		else
		{
			Flist *temp = *f_head,*prev;
			while(temp !=NULL)
			{
    			// check filename repeated or not
				if(strcmp(temp->file_name,name) == 0)
				{
					return REPEATATION;
				}
				prev=temp;
				temp=temp->link;
			}
			prev->link=new;
			return SUCCESS;
		}
}

