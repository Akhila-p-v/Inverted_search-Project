#include "inverted_search.h"

void save_database( Wlist *head[])
{
    int i; 
    char file_name[FNAME_SIZE];

    //prompt the user to enter filename
   	printf("Enter the file name:\n");
	scanf("%s" , file_name);

	//open the file
	FILE *fptr = fopen(file_name ,"w");

	for(i = 0 ; i<27; i++)
	{
	    if(head[i] != NULL)
	    {
		write_databasefile(head[i] , fptr);
	    }
	}
	printf("Database saved\n");
}

//

void write_databasefile(Wlist *head, FILE* databasefile)
{
    // # [index]  : word is [word]  : file count is [file_count] : file\s : file is [file_name] : word count is [word_count]
/*    #[0] : word is [are]: file count is 1:file/s: file is file1.txt: word count is 1
	-------------------------------------------------------------------------
	#[7] : word is [Hi]: file count is 1:file/s: file is file1.txt: word count is 1
	---------------------------------------------------------------------------
	*/
	fprintf(databasefile, "#:%d", tolower(head->word[0])%97);
	fprintf(databasefile, "\n");
	while (head)
	{
		fprintf(databasefile,"word is ");
    	fprintf(databasefile, "[%s]:", head->word);
		fprintf(databasefile,"file count is ");
    	fprintf(databasefile, "%d:", head->file_count);
    	Ltable * temp = head->Tlink;
    	while (temp)
    	{

			fprintf(databasefile,"file is ");
        	fprintf(databasefile, "%s:", temp->file_name);
			fprintf(databasefile,"word count is ");
        	fprintf(databasefile, "%d", temp->word_count);
        	temp = temp->table_link;

    	}
    	head = head->link;
    	fprintf(databasefile, "\n");
	}
}


