#include "inverted_search.h"

void search( Wlist *head, char *word)
{
    //check list empty or not

    if(head == NULL)
    {
		printf("Search word is not present in the list\n");
		return ;
    }

    //traverse through word ist

    while(head)
    {
	//compare the search word with available words

		if(!strcmp(head->word , word))
		{
	    	printf("word %s is present in %d files \n", word , head->file_count);
	   		Ltable *Thead= head->Tlink;

	    	while(Thead)
	    	{
				printf("In file : %s  %d time \n",Thead->file_name , Thead->word_count);

				Thead=Thead->table_link;
	    	}
	    	printf("\n");
	    	return;
		}	
		head = head->link;
    }	
    printf("Search word is not found in the list:\n");
}
