#include "inverted_search.h"
char *fname;
void create_database(Flist *f_head, Wlist *head[])
{
    //traverse through file list
    while(f_head)
    {
	read_datafile(f_head , head , f_head->file_name);
	f_head = f_head->link;
    }
}

//read contents of a file
Wlist * read_datafile(Flist *file, Wlist *head[], char *filename)
{
    fname = filename;
    int flag = 1;
    // open the file read mode
    FILE *fptr = fopen(filename , "r");

    char word[WORD_SIZE];

    while(fscanf(fptr , "%s" , word) != EOF)
    {

		// index
		int	index = tolower(word[0]) % 97 ;
		
		//other than alphabet
		if(!(index >= 0 && index <= 25))
		{
	   		 index = 26;
		}
		//check whether words are repeated or not
		if(head[index] != NULL)
		{
		   Wlist *temp = head[index];
		
		// comparing the words at each node with new word

		while(temp)
		{	
	    	if(!strcmp(temp->word , word))
	    	{
				update_word_count(&temp , filename);
				flag = 0;
				break;
	    	}
			temp = temp->link;
		}
		}	
    
    	if(flag == 1)
		{
			// if words are not repeated
			insert_at_last(&(head[index]) , word);
    	}
	}
}  



int update_word_count(Wlist ** head, char * file_name)
{
    //check whether filenames are same or not
    //if filenames are same ------> increment word_count
	Ltable *temp = (*head)->Tlink;
	Ltable *prev;
	while(temp)
		{
			if(strcmp(temp->file_name ,file_name) == 0)
			{
				(temp->word_count)++;
				return SUCCESS;
			}
			prev = temp;
			temp=temp->table_link;
		}
    // if filenames are different ----- > increment file count , create Ltable
	
		((*head)->file_count)++;
		Ltable *new = malloc(sizeof(Ltable));
		if(new == NULL)
		{
			return FAILURE;
		}
		new->word_count = 1;
		strcpy(new->file_name,file_name);
		new->table_link=NULL;
		prev->table_link = new;
		return SUCCESS;
}

